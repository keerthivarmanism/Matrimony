package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Membership;
import com.example.demo.repository.MembershipRepo;
import com.example.demo.service.MembershipService;

@RestController
public class MembershipController {
	@Autowired
	MembershipRepo MRepo;
	MembershipService Mservice;
	
	@GetMapping("/member/get")
	public List<Membership> getAll(){
		return MRepo.findAll();
	}
	
	@PostMapping("/member/post")
	public Membership create(@RequestBody Membership member) {
		return MRepo.save(member);
	}	

}
