package com.example.demo.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class SignUp {
@Id
private Long id;
private String uname;
private Long phnno;
private String email;
private String password;



public SignUp(Long id, String uname, String email, Long phnno, String password) {
	super();
	this.id = id;
	this.uname = uname;
	this.email = email;
	this.phnno = phnno;
	this.password = password;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public SignUp() {
	super();
	// TODO Auto-generated constructor stub
}
public Long getId() {
	return id;
}
public void setId(Long id) {
	this.id = id;
}
public String getUname() {
	return uname;
}
public void setUname(String uname) {
	this.uname = uname;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public Long getPhnno() {
	return phnno;
}
public void setPhnno(Long phnno) {
	this.phnno = phnno;
}	
}
