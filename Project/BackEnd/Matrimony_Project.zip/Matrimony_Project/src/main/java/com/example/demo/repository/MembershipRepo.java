package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.model.Membership;

public interface MembershipRepo extends JpaRepository<Membership,Integer> {

}
