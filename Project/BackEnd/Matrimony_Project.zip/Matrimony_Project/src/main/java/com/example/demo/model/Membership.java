package com.example.demo.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Membership {
	
	@Id
	private long Mid;
	private String Name;
	private String Status;
	
	public Membership() {
		super();
		// TODO Auto-generated constructor stub
	}

	public long getMid() {
		return Mid;
	}

	public void setMid(long mid) {
		Mid = mid;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public String getStatus() {
		return Status;
	}

	public void setStatus(String status) {
		Status = status;
	}

	public Membership(long mid, String name, String status) {
		super();
		Mid = mid;
		Name = name;
		Status = status;
	}
	
	
	
	

}
